
Hello, 

welcome to my Klein Oak computer science Independent Studies class project!
This project is called Tool Buddy, as it is a Tool Bar icon that is geared 
to create shortcuts to tedious school related things, like checking GPA, 
logging in to Gradespeed, playing a simple game, and more to come! There is 
a link to my website where you can read more about the project or look at other
projects of mine!

In order to run this program, you should create a shortcut of toolBuddy.jar to 
your desktop and just double click it, and an icon will pop up on your tool bar
and sit there for as long as you want, right click this icon to look at the added
shortcuts! Have fun and be sure to visit my website and drop a comment on my github
repo maybe.

Thanks and Enjoy!